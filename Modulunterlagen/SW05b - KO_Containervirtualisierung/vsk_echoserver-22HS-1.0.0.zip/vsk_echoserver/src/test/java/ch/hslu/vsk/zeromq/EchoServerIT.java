/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.zeromq;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;
import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

@Testcontainers
public class EchoServerIT {
    
    private static final Logger LOG = LogManager.getLogger(EchoServerIT.class);
    
    @Container
    public GenericContainer<?> echo = 
            new GenericContainer<>(DockerImageName.parse("rgisler/echoserver:latest"))
                    .withExposedPorts(5555);

    @Test
    public void testServerStart() {
        final String logs = echo.getLogs();
        LOG.info(logs);
        Assertions.assertThat(logs).contains("Echo server started");
    }

    @Test
    public void testServerSendAndReceiveEcho() {
        final String ip = echo.getHost();
        final int port = echo.getFirstMappedPort();
        final String url = "tcp://" + ip + ":" + port; 
        ZMQ.Socket socket = new ZContext().createSocket(SocketType.REQ);
        socket.connect(url);
        socket.send("TEST-NACHRICHT".getBytes(ZMQ.CHARSET));
        final String response = new String(socket.recv(), ZMQ.CHARSET);
        Assertions.assertThat(response).isEqualTo("TEST-NACHRICHT");
        final String logs = echo.getLogs();
        LOG.info("Connected to: {}", url);
        LOG.info(logs);
        Assertions.assertThat(logs).contains("TEST-NACHRICHT");
    }
    
}
