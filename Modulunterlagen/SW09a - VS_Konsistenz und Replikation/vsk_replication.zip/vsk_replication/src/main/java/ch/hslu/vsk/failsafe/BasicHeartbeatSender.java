package ch.hslu.vsk.failsafe;

import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

import java.io.IOException;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * A heartbeat sender implemented using the ZeroMQ-library.
 */
public class BasicHeartbeatSender {
    private static final long HEARTBEAT_INTERVAL = 100;
    private final ScheduledThreadPoolExecutor executor = new ScheduledThreadPoolExecutor(1);
    private ZContext zContext;
    private ZMQ.Socket socket;

    private final Runnable action = new Runnable() {
        @Override
        public void run() {
            socket.send(new byte[0]);
        }
    };

    public void start() {
        zContext = new ZContext();
        socket = zContext.createSocket(SocketType.PUB);
        socket.bind("tcp://localhost:7777");
        executor.scheduleWithFixedDelay(action, HEARTBEAT_INTERVAL, HEARTBEAT_INTERVAL, TimeUnit.MILLISECONDS);
    }

    public void stop() {
        executor.shutdown();
        zContext.close();
    }

    public static void main(String[] args) throws IOException, InterruptedException {
        BasicHeartbeatSender heartbeatSender = new BasicHeartbeatSender();
        heartbeatSender.start();
        System.in.read();
        heartbeatSender.stop();
    }
}
