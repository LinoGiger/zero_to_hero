package ch.hslu.vsk.failsafe;

import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

import java.io.IOException;

/**
 * A heartbeat detector implemented using the ZeroMQ-library.
 */
public class BasicHeartbeatDetector {
    private static final int HEARTBEAT_DETECT_INTERVAL = 1000; // [ms]
    private ZContext zContext;
    private ZMQ.Socket socket;
    private final Runnable noResponseHandler;
    private volatile boolean running;

    public BasicHeartbeatDetector(Runnable noResponseHandler) {
        this.noResponseHandler = noResponseHandler;
    }

    private final Runnable action = new Runnable() {
        @Override
        public void run() {
            while(running) {
                byte[] reply = socket.recv();
                if (reply == null) {
                    running = false;
                    noResponseHandler.run();
                }
            }
        }
    };

    public void start() {
        zContext = new ZContext();
        socket = zContext.createSocket(SocketType.SUB);
        socket.subscribe(new byte[0]);
        socket.connect("tcp://localhost:7777");
        socket.setReceiveTimeOut(HEARTBEAT_DETECT_INTERVAL);
        Thread thread = new Thread(action);
        running = true;
        thread.start();
    }

    public void stop() {
        running = false;
        zContext.close();
    }

    public static void main(String[] args) throws IOException {
        BasicHeartbeatDetector heartbeatDetector = new BasicHeartbeatDetector(new Runnable() {
            @Override
            public void run() {
                System.out.println("Heartbeat not detected");
            }
        });

        heartbeatDetector.start();
        System.in.read();
        heartbeatDetector.stop();
    }
}
