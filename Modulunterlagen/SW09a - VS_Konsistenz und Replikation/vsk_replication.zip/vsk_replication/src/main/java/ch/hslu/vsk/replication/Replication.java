/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.replication;

import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * Replication thread implemented using a producer-consumer pattern.
 * Original thread is the producer and inserts messages. The replication
 * thread consumes the messages and forwards them to a replication server.
 * Original thread can wait for replication to complete.
 */
public class Replication implements Runnable {
    private final String replicationAddress;
    private final Queue<Message> replicationQueue = new ConcurrentLinkedQueue<>();

    public Replication(String replicationAddress) {
        this.replicationAddress = replicationAddress;
    }

    @Override
    public void run() {
        try (ZContext context = new ZContext()) {
            System.out.printf("Connecting to replica at %s\n", replicationAddress);
            ZMQ.Socket socket = context.createSocket(SocketType.REQ);
            socket.connect(replicationAddress);
            processReplicationQueue(socket);
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    public void addMessage(Message message) {
        replicationQueue.add(message);
        notifyWaiters();
    }

    public void waitForSynchronization() {
        waitForCondition(true);
    }

    private synchronized void waitForCondition(boolean isEmpty) {
        while (replicationQueue.isEmpty() != isEmpty) {
            try {
                this.wait();
            } catch (InterruptedException e) {
                throw new RuntimeException(e); // cannot occur
            }
        }
    }

    private void processReplicationQueue(ZMQ.Socket socket) {
        while(true) {
            waitForCondition(false);
            Message message = replicationQueue.peek();
            socket.send(message.toString());
            socket.recvStr();
            replicationQueue.remove();
            notifyWaiters();
        }
    }

    private synchronized void notifyWaiters() {
        this.notify();
    }
}
