/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.replication;

import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

/**
 * A server that showcases basic replication using a minimal accounting implementation.
 * The server can:
 * - Create accounts with an initial balance.
 * - Transfer money between accounts.
 * - Show current account balance.
 * Note: to keep things simple, the server does NOT perform any kinds of checks.
 */
public class AccountServer {
    private final String listenAddress;
    private final Replication replication;
    private final AccountStorage accountStorage;
    private final boolean isPrimary;

    public AccountServer(String listenAddress, Replication replication, AccountStorage accountStorage, boolean isPrimary) {
        this.listenAddress = listenAddress;
        this.replication = replication;
        this.accountStorage = accountStorage;
        this.isPrimary = isPrimary;
    }

    public void run() {
        try (ZContext context = new ZContext()) {
            System.out.printf("Account server started in mode %s - listening on %s\n", isPrimary ? "primary" : "replica", listenAddress);
            ZMQ.Socket socket = context.createSocket(SocketType.REP);
            socket.bind(listenAddress);
            processMessages(socket);
        }
    }

    private void processMessages(ZMQ.Socket socket) {
        if (isPrimary) {
            new Thread(replication).start();
        }
        while(true) {
            Message request = new Message(socket.recvStr());
            try {
                Message reply = switch (request.getCommand()) {
                    case "create" -> onCreate(request);
                    case "transfer" -> onTransfer(request);
                    case "balance" -> onBalance(request);
                    default -> throw new Message.ParseException("unknown message: " + request.getCommand());
                };
                if (isPrimary) {
                    replication.addMessage(request);
                }
                socket.send(reply.toString());
            } catch (Message.ParseException e) {
                System.err.printf("cannot parse message: %s\n", request.getCommand());
                socket.send("error");
            }
        }
    }

    private Message onCreate(Message message) throws Message.ParseException {
        String name = message.getString(0);
        int amount = message.getInt(1);
        System.out.printf("create account for '%s' with initial balance '%d'\n", name, amount);
        accountStorage.createAccount(name, amount);
        return new Message("created");
    }

    private Message onTransfer(Message message) throws Message.ParseException {
        String from = message.getString(0);
        String to = message.getString(1);
        int amount = message.getInt(2);
        System.out.printf("transfer '%d' from account '%s' to account '%s'\n", amount, from, to);
        accountStorage.transferAmount(from, to, amount);
        return new Message("transfered");
    }

    private Message onBalance(Message message) throws Message.ParseException {
        String name = message.getString(0);
        long balance = accountStorage.getBalance(name);
        System.out.printf("account balance is: '%d'\n", balance);
        return new Message("balance " + balance);
    }

    /**
     * Main method: Parses arguments and starts AccountServer
     */
    public static void main(String[] args) {
        if (args.length < 4) {
            System.out.println("Usage: java AccountServer databaseLocation listenAddress replicationAddress (primary|replica)");
            System.exit(1);
        }
        AccountStorage accountStorage = new AccountStorage(args[0]);
        String listenAddress = args[1];
        Replication replication = new Replication(args[2]);
        boolean isPrimary = args[3].equals("primary");
        AccountServer accountServer = new AccountServer(listenAddress, replication, accountStorage, isPrimary);
        accountServer.run();
        accountStorage.close();
    }
}
