/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.replication;

import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Client programm for an account server.
 */
public class AccountClient {
    /**
     * Main method. Parses arguments and starts AccountClient.
     */
    public static void main(final String[] args) {
        if (args.length < 1) {
            System.out.println("Usage: java AccountClient serverAddress");
            System.exit(1);
        }
        String serverAddress = args[0];
        new AccountClient(serverAddress);
    }

    /**
     * On entering "exit" the application terminates.
     */
    private AccountClient(String serverAddress) {
        System.out.println("Echo client connecting to " + serverAddress);
        try (ZContext context = new ZContext()) {
            ZMQ.Socket socket = context.createSocket(SocketType.REQ);
            socket.connect(serverAddress);
            BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));
            while (true) {
                System.out.print("Enter command (exit for terminate): ");
                String input = userIn.readLine();
                if (input.equals("exit")) {
                    break;
                }
                socket.send(input);
                System.out.println("Received reply: " + socket.recvStr());
            }
            System.out.println("Application terminated.");
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }
}
