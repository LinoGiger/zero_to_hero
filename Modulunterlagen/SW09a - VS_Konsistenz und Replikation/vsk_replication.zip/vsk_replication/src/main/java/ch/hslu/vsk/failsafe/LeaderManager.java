/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.failsafe;

import org.apache.zookeeper.*;
import org.apache.zookeeper.Watcher.Event.KeeperState;
import org.apache.zookeeper.ZooDefs.Ids;
import org.apache.zookeeper.data.Stat;

import java.nio.charset.StandardCharsets;
import java.util.concurrent.CountDownLatch;

/**
 * Example implementation of a leader election using ZooKeeper.
 */
public class LeaderManager implements Runnable {
    private static final String LEADER_NODE_PATH = "/myAppLeader";

    private final String myName;
    private final String hosts;
    private String leader;
    private ZooKeeper zk;
    private Stat stat;
    private volatile boolean running;
    private boolean changed;

    public LeaderManager(String hosts, String name) {
        this.hosts = hosts;
        this.myName = name;
    }

    public void stop() {
        running = false;
    }

    private synchronized void setChanged() {
        changed = true;
        notifyAll();
    }

    private synchronized void waitForChanges() {
        while (!changed) {
            try {
                wait();
            } catch (InterruptedException e) {
                throw new IllegalStateException(e); // cannot occur
            }
        }
    }

    @Override
    public void run() {
        running = true;
        try {
            connect(hosts);
            while (running) {
                changed = false;
                try {
                    zk.create(LEADER_NODE_PATH, myName.getBytes(StandardCharsets.US_ASCII), Ids.OPEN_ACL_UNSAFE, CreateMode.EPHEMERAL);
                    leader = myName;
                } catch (KeeperException.NodeExistsException e) {
                    try {
                        byte[] data = zk.getData(LEADER_NODE_PATH, event -> setChanged(), stat);
                        leader = new String(data, StandardCharsets.US_ASCII);
                    } catch (KeeperException.NoNodeException ex) {
                        setChanged();
                    }
                } catch (KeeperException | InterruptedException ex) {
                    throw new RuntimeException(ex);
                }
                System.out.println("leader is " + leader);
                waitForChanges();
            }
            zk.close();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void connect(String host) throws Exception {
        CountDownLatch connSignal = new CountDownLatch(1);
        zk = new ZooKeeper(host, 3000, new Watcher() {
            public void process(WatchedEvent event) {
                if (event.getState() == KeeperState.SyncConnected) {
                    connSignal.countDown();
                }
            }
        });
        connSignal.await();
    }

    public static void main (String args[]) throws Exception {
        System.out.println("my name is: " + args[0]);
        LeaderManager leaderManager = new LeaderManager("127.0.0.1:2181", args[0]);
        new Thread(leaderManager).start();
        System.in.read();
        leaderManager.stop();
    }
}
