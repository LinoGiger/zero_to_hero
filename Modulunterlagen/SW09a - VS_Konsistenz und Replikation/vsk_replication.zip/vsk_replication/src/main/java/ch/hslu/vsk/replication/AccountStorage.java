/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.replication;

import java.sql.*;

/**
 * Implements an Account storage using the in-process database H2.
 * The implementations stores all data locally in a file using the name
 * and location passed in the constructor.
 * Note: to keep things simple, the implementations does NOT perform any kinds of checks.
 */
public class AccountStorage {
    private Connection connection;
    private PreparedStatement createAccountStatement;
    private PreparedStatement updateAccountStatement;
    private PreparedStatement getAccountBalanceStatement;

    public AccountStorage(String databaseLocation) {
        initializeDatabase(databaseLocation);
    }

    public void createAccount(String name, long amount) {
        try {
            createAccountStatement.setString(1, name);
            createAccountStatement.setLong(2, amount);
            createAccountStatement.executeUpdate();
            connection.commit();
        } catch (SQLException e) {
            throw new RuntimeException("error while creating account", e);
        }
    }

    public void transferAmount(String from, String to, long amount) {
        try {
            updateAccountStatement.setLong(1, -amount);
            updateAccountStatement.setString(2, from);
            updateAccountStatement.execute();
            updateAccountStatement.setLong(1, amount);
            updateAccountStatement.setString(2, to);
            updateAccountStatement.execute();
            connection.commit();
        } catch (SQLException e) {
            throw new RuntimeException("error while transfering money", e);
        }
    }

    public long getBalance(String name) {
        try {
            getAccountBalanceStatement.setString(1, name);
            ResultSet rs = getAccountBalanceStatement.executeQuery();
            rs.next();
            return rs.getLong(1);
        } catch (SQLException e) {
            throw new RuntimeException("error while retriveing acoount balance", e);
        }
    }

    public void close() {
        try {
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException("error while closing database", e);
        }
    }

    private void initializeDatabase(String databaseLocation) {
        try {
            connection = DriverManager.getConnection("jdbc:h2:" + databaseLocation, "sa", "");
            connection.setAutoCommit(false);
            Statement statement = connection.createStatement();
            statement.execute("create table if not exists accounts(name varchar(1000), amount bigint)");
            createAccountStatement = connection.prepareStatement("insert into accounts values (?, ?)");
            updateAccountStatement = connection.prepareStatement("update accounts set amount = amount + ? where name = ?");
            getAccountBalanceStatement = connection.prepareStatement("select amount from accounts where name = ?");
        } catch (SQLException e) {
            throw new RuntimeException("error while initializing database", e);
        }
    }
}
