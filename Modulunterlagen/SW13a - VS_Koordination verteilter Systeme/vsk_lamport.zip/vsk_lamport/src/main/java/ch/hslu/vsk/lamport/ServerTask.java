/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.lamport;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Server, der Nachrichten empfängt und aufgrund der Prozessnummer an den
 * entsprechenden Prozess weiter sendet.
 */
public final class ServerTask implements Runnable {

    private static final Logger LOG = LogManager.getLogger(ServerTask.class);
    private final LamportServer server;
    private ObjectInputStream inputStream;

    /**
     * Konstruktor des Server Threads, der im Lamport Server gestartet wird.
     *
     * @param server Lamport Server mit den Verbindungen zu allen Lamport
     * Prozessen.
     * @param socket eines Lamport Prozesses.
     */
    public ServerTask(final LamportServer server, final Socket socket) {
        this.server = server;
        try {
            this.inputStream = new ObjectInputStream(socket.getInputStream());
        } catch (IOException ex) {
            LOG.fatal(ex);
        }
    }

    @Override
    public void run() {
        CommunicationMessage message;
        ObjectOutputStream outputStream;
        while (true) {
            try {
                message = (CommunicationMessage) inputStream.readObject();
                outputStream = server.getOutputConnections().get(message.getReceivingProcessNumber() - 1);
                outputStream.writeObject(message);
            } catch (IOException | ClassNotFoundException ex) {
                LOG.fatal(ex);
            }
        }
    }
}
