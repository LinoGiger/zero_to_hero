/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.lamport;

/**
 * Nachricht, welche von simuliertem Prozess zu Prozess gesendet wird.
 */
public final class CommunicationMessage implements Message {

    private static final long serialVersionUID = 4748146019417283829L;

    private final int sendingProcessNumber;
    private final int time;
    private final int receivingProcessNumber;

    /**
     * Erzeugt eine Nachricht.
     *
     * @param sendingProcessNumber Prozessnummer des aktuellen Lamport
     * Prozesses.
     * @param time Zeit des aktuellen Lamport Prozesses.
     * @param receivingProcessNumber Prozessnummer des Lamport Prozesses, der
     * die Nachricht gesendet hat.
     */
    public CommunicationMessage(final int sendingProcessNumber, final int time, final int receivingProcessNumber) {
        this.sendingProcessNumber = sendingProcessNumber;
        this.time = time;
        this.receivingProcessNumber = receivingProcessNumber;
    }

    /**
     * Gibt die Prozessnummer des aktuellen Lamport Prozesses zurück.
     *
     * @return Prozessnummer.
     */
    public int getSendingProcessNumber() {
        return sendingProcessNumber;
    }

    /**
     * Gibt die aktuelle Zeit des aktuellen Lamport Prozesses zurück.
     *
     * @return Zeit
     */
    public int getTime() {
        return time;
    }

    /**
     * Gibt die Prozessnummer des Lamport Prozesses zurück, von dem die
     * Nachricht stammt.
     *
     * @return Prozessnummer.
     */
    public int getReceivingProcessNumber() {
        return receivingProcessNumber;
    }
}
