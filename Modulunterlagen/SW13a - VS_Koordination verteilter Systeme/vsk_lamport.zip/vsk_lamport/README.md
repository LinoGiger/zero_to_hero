# Java Samples für Modul VSK

Dieses Projekt enthält verschiedene Samples für das Modul VSK.

** Achtung**: Die Entwicklung findet auf dem develop-Branch statt! 

Der master-Branch ist geschützt (kein push möglich) und wird bei erfolgreichem Build des
develop-Branches vom Buildserver automatisch gemerged. Somit ist der master-Branch immer 
baubar und lauffähig (sofern dies durch ausreichende Testfälle abgesichert wird).

## Buildstatus
* develop [![Build Status](https://jenkins-global.el.eee.intern/jenkins/buildStatus/icon?job=vsk_samples-develop)](https://jenkins-global.el.eee.intern/jenkins/job/vsk_samples-develop/)
* master [![Build Status](https://jenkins-global.el.eee.intern/jenkins/buildStatus/icon?job=vsk_samples-master)](https://jenkins-global.el.eee.intern/jenkins/job/vsk_samples-master/)

> Hinweis: Nur innerhalb des HSLU-Netzes sichtbar.
