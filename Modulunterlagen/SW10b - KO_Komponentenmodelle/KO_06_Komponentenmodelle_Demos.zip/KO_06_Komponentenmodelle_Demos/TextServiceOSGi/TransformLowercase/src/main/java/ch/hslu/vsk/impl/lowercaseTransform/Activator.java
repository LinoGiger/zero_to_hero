package ch.hslu.vsk.impl.lowercaseTransform;

import ch.hslu.vsk.textservice.TextService;
import org.osgi.framework.BundleActivator;
import org.osgi.framework.BundleContext;

import java.util.Hashtable;

public class Activator implements BundleActivator {
    public void start(BundleContext context) {
        Hashtable<String, String> properties = new Hashtable<>();
        properties.put("name", "Lowercase Transform");
        context.registerService(TextService.class.getName(), new TextServiceImpl(), properties);
    }

    public void stop(BundleContext context) {
    }
}