package ch.hslu.vsk.impl.transformClient;

import org.osgi.framework.*;

import javax.swing.*;

public class Activator implements BundleActivator {
    private JFrame main;

    public void start(BundleContext context) {
        main = TransformerClient.createForm(context);
    }

    public void stop(BundleContext context) {
        main.dispose();
    }
}