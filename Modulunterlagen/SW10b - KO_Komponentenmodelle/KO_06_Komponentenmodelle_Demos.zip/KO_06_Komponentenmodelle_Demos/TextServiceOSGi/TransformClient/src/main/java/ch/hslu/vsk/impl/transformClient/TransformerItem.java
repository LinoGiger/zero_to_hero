package ch.hslu.vsk.impl.transformClient;

import org.osgi.framework.ServiceReference;

class TransformerItem {
    ServiceReference ref;

    public TransformerItem(ServiceReference ref) {
        this.ref = ref;
    }

    public ServiceReference getRef() {
        return ref;
    }

    @Override
    public String toString() {
        String name = (String) ref.getProperty("name");
        return name != null ? name : ref.toString();
    }
}
