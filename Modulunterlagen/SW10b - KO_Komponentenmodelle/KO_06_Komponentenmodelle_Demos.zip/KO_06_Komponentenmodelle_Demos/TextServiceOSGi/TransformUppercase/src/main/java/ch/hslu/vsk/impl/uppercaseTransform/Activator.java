package ch.hslu.vsk.impl.uppercaseTransform;

import ch.hslu.vsk.textservice.*;
import org.osgi.framework.*;

import java.util.Hashtable;

public class Activator implements BundleActivator {
    public void start(BundleContext context) {
        Hashtable<String, String> properties = new Hashtable<>();
        properties.put("name", "Uppercase Transform");
        context.registerService(TextService.class.getName(), new TextServiceImpl(), properties);
    }

    public void stop(BundleContext context) {
    }
}