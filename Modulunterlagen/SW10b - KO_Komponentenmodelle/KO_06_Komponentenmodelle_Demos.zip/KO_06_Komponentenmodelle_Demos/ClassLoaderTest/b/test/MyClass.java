package test;

public class MyClass {
    public static void getMessage() {
        System.out.println("Version B");
    }
}
