import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;

public class ClassLoaderTest {
    public static void main(String[] args) throws MalformedURLException, ClassNotFoundException, InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException {
        URLClassLoader a = new URLClassLoader(new URL[] { new URL("file:a/") });
        URLClassLoader b = new URLClassLoader(new URL[] { new URL("file:b/") });
        Class c1 = a.loadClass("test.MyClass");
        Class c2 = b.loadClass("test.MyClass");
        Method method1 = c1.getDeclaredMethod("getMessage");
        Method method2 = c2.getDeclaredMethod("getMessage");
        method1.invoke(null);
        method2.invoke(null);
    }
}
