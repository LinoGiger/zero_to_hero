package ch.hslu.vsk.impl.util;

public class StringUtil {
    public static String transformLower(String text) {
        return text.toLowerCase();
    }

    public static String transformUpper(String text) {
        return text.toUpperCase();
    }
}
