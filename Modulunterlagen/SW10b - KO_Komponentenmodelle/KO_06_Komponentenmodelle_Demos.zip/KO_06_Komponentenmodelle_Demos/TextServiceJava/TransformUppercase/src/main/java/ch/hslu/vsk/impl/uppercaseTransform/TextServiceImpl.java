package ch.hslu.vsk.impl.uppercaseTransform;

import ch.hslu.vsk.textservice.*;
import ch.hslu.vsk.impl.util.StringUtil;

public class TextServiceImpl implements TextService {
    @Override
    public String translate(String text) {
        return StringUtil.transformUpper(text);
    }
}
