package ch.hslu.vsk.impl.lowercaseTransform;

import ch.hslu.vsk.textservice.*;
import ch.hslu.vsk.impl.util.StringUtil;

public class TextServiceImpl implements TextService {

    @Override
    public String translate(String text) {
        return StringUtil.transform(text, false);
    }
}
