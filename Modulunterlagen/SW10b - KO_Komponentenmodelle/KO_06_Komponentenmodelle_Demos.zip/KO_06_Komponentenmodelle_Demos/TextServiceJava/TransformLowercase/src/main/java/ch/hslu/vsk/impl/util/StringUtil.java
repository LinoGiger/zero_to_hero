package ch.hslu.vsk.impl.util;

public class StringUtil {
    public static String transform(String text, boolean upperCase) {
        if (upperCase) {
            return text.toUpperCase();
        } else {
            return text.toLowerCase();
        }
    }
}
