package ch.hslu.vsk.impl.transformClient;

import ch.hslu.vsk.textservice.TextService;

class TransformerItem {
    TextService textService;

    public TransformerItem(TextService textService) {
        this.textService = textService;
    }

    public TextService getRef() {
        return textService;
    }

    @Override
    public String toString() {
        return textService.getClass().getName();
    }
}
