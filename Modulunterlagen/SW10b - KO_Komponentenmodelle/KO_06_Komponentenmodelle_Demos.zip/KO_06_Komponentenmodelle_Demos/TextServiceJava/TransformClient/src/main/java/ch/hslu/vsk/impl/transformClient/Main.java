package ch.hslu.vsk.impl.transformClient;

import ch.hslu.vsk.textservice.TextService;
import ch.hslu.vsk.textservice.TextServiceFactory;

import java.util.LinkedList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        List<TextService> textServices = new LinkedList<>();
        if (args.length > 0) {
            String[] classNames = args[0].split(",");
            for (String className : classNames) {
                textServices.add(TextServiceFactory.createTextServiceInstance(className));
            }
        }
        TransformerClient.createForm(textServices);
    }
}
