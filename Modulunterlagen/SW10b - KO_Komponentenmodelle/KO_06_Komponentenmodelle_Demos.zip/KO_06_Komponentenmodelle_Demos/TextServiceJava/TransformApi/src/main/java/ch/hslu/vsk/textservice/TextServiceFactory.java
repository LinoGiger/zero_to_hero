package ch.hslu.vsk.textservice;

import java.lang.reflect.InvocationTargetException;

public class TextServiceFactory {
    public static TextService createTextServiceInstance(String className) {
        try {
            Class<?> clazz = Class.forName(className);
            Object object = clazz.getDeclaredConstructor().newInstance();
            if (!(object instanceof TextService)) {
                throw new RuntimeException("cannot create new text service instance of class '" + className + "': class does not implement interface 'TextService'");
            }
            return (TextService) object;
        } catch (ClassNotFoundException | InstantiationException | InvocationTargetException | NoSuchMethodException | IllegalAccessException e) {
            throw new RuntimeException("cannot create new text service instance of class '" + className + "'", e);
        }
    }
}
