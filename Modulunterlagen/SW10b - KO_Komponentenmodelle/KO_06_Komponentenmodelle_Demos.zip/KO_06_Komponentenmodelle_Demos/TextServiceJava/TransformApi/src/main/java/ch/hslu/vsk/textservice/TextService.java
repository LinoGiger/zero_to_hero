package ch.hslu.vsk.textservice;

public interface TextService {
    /**
     * Returns the input string in uppercase letters.
     * @param text to be converted.
     * @return text in uppercase letters.
     */
    String translate(String text);
}
