/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.datagrid.producerdemo;

import java.util.concurrent.BlockingQueue;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.client.config.ClientNetworkConfig;
import com.hazelcast.core.HazelcastInstance;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/**
 * Schreibt in die Queue.
 */
public final class HazelcastQueueConsumer {

    private static final Logger LOG = LogManager.getLogger(HazelcastQueueConsumer.class);

    /**
     * Privater Konstruktor.
     */
    private HazelcastQueueConsumer() {
    }

    /**
     * Startet einen Consumer.
     *
     * @param args not used.
     */
    public static void main(final String[] args) {
        final ClientConfig clientConfig = new ClientConfig();
        clientConfig.setClusterName("demo-cluster");
        final int id = new Random().nextInt(100);
        clientConfig.setInstanceName("Consumer " + id);
        final ClientNetworkConfig clientNetworkConfig = new ClientNetworkConfig();
        clientConfig.setNetworkConfig(clientNetworkConfig);
        final HazelcastInstance hc = HazelcastClient.newHazelcastClient(clientConfig);
        boolean finished = false;
        while (!finished) {
            try {
                final BlockingQueue<String> queue = hc.getQueue("demo-queue");
                for (int i = 0; i < 100000; i++) {
                    Thread.sleep(23);
                    final String message = queue.poll(1, TimeUnit.SECONDS);
                    if (message != null) {
                        LOG.info("Consumer {}: Entry[{}] processed.", id, message);
                    } else {
                        LOG.info("Consumer {}: waiting...", id);
                        i--;
                    }
                }
                finished = true;
            } catch (Exception e) {
                LOG.debug(e.getMessage());
            }
        }
    }
}
