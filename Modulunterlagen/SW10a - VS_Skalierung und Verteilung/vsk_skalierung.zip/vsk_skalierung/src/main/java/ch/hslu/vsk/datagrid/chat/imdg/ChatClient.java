/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.datagrid.chat.imdg;

import ch.hslu.vsk.datagrid.chat.gui.ChatFrame;
import ch.hslu.vsk.datagrid.chat.gui.EnterListener;
import ch.hslu.vsk.datagrid.chat.gui.ExitListener;
import ch.hslu.vsk.datagrid.chat.message.ChatManager;
import ch.hslu.vsk.datagrid.chat.message.ChatMessage;
import com.hazelcast.topic.Message;
import com.hazelcast.topic.MessageListener;
import java.util.UUID;
import javax.swing.JFrame;

/**
 * Chat Teilnehmer.
 */
public final class ChatClient implements MessageListener<ChatMessage> {

    private final String name;
    private UUID registrationId;
    private ChatFrame gui;
    private final ChatManager manager;

    /**
     * Erzeugt einen Chat Teilnehmer.
     *
     * @param name Name des Chat Teilnehmer.
     * @param manager Chat Manager für die Registrierung des Teilnehmers.
     */
    @SuppressWarnings("LeakingThisInConstructor")
    public ChatClient(String name, ChatManager manager) {
        this.name = name;
        this.registrationId = null;
        this.initGui();
        this.manager = manager;
        this.manager.login(this, new ChatMessage(name, "dem Chat beigetreten..."));
    }

    private void initGui() {
        gui = new ChatFrame(name);
        gui.input.addKeyListener(new EnterListener(this, gui));
        gui.addWindowListener(new ExitListener(this));
        gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        gui.setVisible(true);
    }

    /**
     * Setzt die ID des Cluster Clients.
     *
     * @param registrationId ID des Cluster Clients.
     */
    public void setRegistrationId(final UUID registrationId) {
        this.registrationId = registrationId;
    }

    /**
     * Gibt die ID des Cluster Clients zurück.
     *
     * @return ID des Cluster Clients..
     */
    public UUID getRegistrationId() {
        return registrationId;
    }

    /**
     * Event.
     *
     * @param msg ChatMessage.
     */
    @Override
    public void onMessage(Message<ChatMessage> msg) {
        ChatMessage chatMessage = msg.getMessageObject();
        gui.output.append(chatMessage.getName() + ": " + chatMessage.getText() + "\n");
    }

    /**
     * Nachrichtentext senden.
     *
     * @param text Nachrichtentext.
     */
    public void sendMessage(final String text) {
        manager.notifyClients(new ChatMessage(name, text));
    }

    /**
     * Teilnehmer vom Chat abmelden.
     */
    public void disconnect() {
        manager.logout(this, new ChatMessage(name, "verlässt den Chat."));
    }
}
