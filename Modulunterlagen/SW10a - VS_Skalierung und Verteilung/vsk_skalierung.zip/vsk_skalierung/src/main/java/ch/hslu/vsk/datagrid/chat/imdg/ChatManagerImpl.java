/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.datagrid.chat.imdg;

import ch.hslu.vsk.datagrid.chat.message.ChatManager;
import ch.hslu.vsk.datagrid.chat.message.ChatMessage;
import com.hazelcast.config.Config;
import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.topic.ITopic;
import java.util.UUID;

/**
 * Chat Manager für eine Hazelcast Applikation. Chat Manager verwaltet die
 * angemeldeten Chat Teilnehmer und versendet die Nachrichten zwischen den Chat
 * Teilnehmern.
 */
public final class ChatManagerImpl implements ChatManager {

    private final String HC_ID;
    private final HazelcastInstance hi;
    private static volatile ChatManager manager = null;

    private ChatManagerImpl() {
        this.HC_ID = "chat";
        final Config config = new Config();
        config.setClusterName("demo-cluster");
        config.getManagementCenterConfig().setScriptingEnabled(true);
        this.hi = Hazelcast.newHazelcastInstance(config);
    }

    /**
     * Gibt eine ChatManagerImpl Instanz zurück.
     * 
     * @return ChatManagerImpl.
     */
    public final static ChatManager getInstance() {
        if (manager == null) {
            manager = new ChatManagerImpl();
        }
        return manager;
    }
    
    @Override
    public void login(final ChatClient client, final ChatMessage msg) {
        final ITopic<ChatMessage> topic = hi.getTopic(HC_ID);
        UUID uuid = topic.addMessageListener(client);
        client.setRegistrationId(uuid);
        notifyClients(msg);
    }

    @Override
    public void logout(final ChatClient client, final ChatMessage msg) {
        final ITopic<ChatMessage> topic = hi.getTopic(HC_ID);
        topic.removeMessageListener(client.getRegistrationId());
        notifyClients(msg);
    }

    @Override
    public void notifyClients(final ChatMessage msg) {
        final ITopic<ChatMessage> topic = hi.getTopic(HC_ID);
        topic.publish(msg);
    }
}
