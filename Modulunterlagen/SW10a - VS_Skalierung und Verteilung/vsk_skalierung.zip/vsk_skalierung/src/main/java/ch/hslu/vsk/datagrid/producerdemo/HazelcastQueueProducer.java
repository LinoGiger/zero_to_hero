/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.datagrid.producerdemo;

import java.util.concurrent.BlockingQueue;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.client.config.ClientNetworkConfig;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.cp.IAtomicLong;
import java.util.Random;
import java.util.concurrent.TimeUnit;

/**
 * Schreibt in die Queue.
 */
public final class HazelcastQueueProducer {

    private static final Logger LOG = LogManager.getLogger(HazelcastQueueProducer.class);

    /**
     * Privater Konstruktor.
     */
    private HazelcastQueueProducer() {
    }

    /**
     * Startet einen Producer.
     *
     * @param args not used.
     */
    public static void main(final String[] args) {
        final ClientConfig clientConfig = new ClientConfig();
        clientConfig.setClusterName("demo-cluster");
        final int id = new Random().nextInt(100);
        clientConfig.setInstanceName("Producer " + id);
        final ClientNetworkConfig clientNetworkConfig = new ClientNetworkConfig();
        clientConfig.setNetworkConfig(clientNetworkConfig);
        final HazelcastInstance hc = HazelcastClient.newHazelcastClient(clientConfig);
        boolean finished = false;
        while (!finished) {
            try {
                final BlockingQueue<String> queue = hc.getQueue("demo-queue");
                final IAtomicLong counter = hc.getCPSubsystem().getAtomicLong("demo-counter");
                for (int i = 0; i < 100000; i++) {
                    Thread.sleep(19);
                    final long numb = counter.incrementAndGet();
                    final String message = "Queue Entry " + numb;
                    boolean offer = queue.offer(message, 1, TimeUnit.SECONDS);
                    if (offer) {
                        LOG.info("Producer {}: Entry[{}] produced.", id, message);
                    } else {
                        LOG.info("Producer {}: waiting...", id);
                        i--;
                    }
                }
                finished = true;
            } catch (Exception e) {
                LOG.debug(e.getMessage());
            }
        }
    }
}
