/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.datagrid.datastructures;

import ch.hslu.vsk.datagrid.datastructures.model.MyMessage;
import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.topic.ITopic;
import com.hazelcast.topic.Message;
import com.hazelcast.topic.MessageListener;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Demo Distributed Topic.
 */
public final class DistributedTopic implements MessageListener<MyMessage> {

    private static final Logger LOG = LogManager.getLogger(DistributedTopic.class);

    /**
     * Demo.
     *
     * @param args werden nicht benötigt/berücksichtigt.
     */
    public static void main(final String[] args) {
        final ClientConfig clientConfig = new ClientConfig();
        clientConfig.setClusterName("demo-cluster");
        final HazelcastInstance client = HazelcastClient.newHazelcastClient(clientConfig);

        // create topic "default", add listener and publish a single message
        final DistributedTopic distributedTopic = new DistributedTopic();
        final ITopic<MyMessage> topic = client.getTopic("default");
        topic.addMessageListener(distributedTopic);
        topic.publish(new MyMessage("my message object", "hello"));

        client.shutdown();
    }

    /**
     * Event.
     * 
     * @param msg Message.
     */
    @Override
    public void onMessage(Message<MyMessage> msg) {
        final MyMessage message = msg.getMessageObject();
        LOG.info("Got msg: " + message.getText() + " from " + message.getName());
    }
}
