/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.datagrid.datastructures;

import ch.hslu.vsk.datagrid.datastructures.model.Customer;
import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;
import java.util.concurrent.ConcurrentMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Demo Distributed Map.
 */
public final class DistributedMap {

    private static final Logger LOG = LogManager.getLogger(DistributedMap.class);

    /**
     * Demo.
     *
     * @param args werden nicht benötigt/berücksichtigt.
     */
    public static void main(final String[] args) {
        final ClientConfig clientConfig = new ClientConfig();
        clientConfig.setClusterName("demo-cluster");
        final HazelcastInstance client = HazelcastClient.newHazelcastClient(clientConfig);

        // create concurrent map
        final ConcurrentMap<String, Customer> map = client.getMap("customers");
        Customer customer = new Customer("John Doe", 21, false);
        map.put("4711", customer);
        customer = map.get("4711");
        LOG.info(customer);

        // concurrentMap methods
        map.putIfAbsent("4712", new Customer("Chuck Norris", 80));
        map.replace("4711", new Customer("Bruce Lee"));
        customer = map.get("4711");
        LOG.info(customer);
        customer = map.get("4712");
        LOG.info(customer);

        client.shutdown();
    }
}
