/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.datagrid.datastructures;

import ch.hslu.vsk.datagrid.datastructures.model.Task;
import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Demo Distributed Queue.
 */
public final class DistributedQueue {

    private static final Logger LOG = LogManager.getLogger(DistributedQueue.class);

    /**
     * Demo.
     *
     * @param args werden nicht benötigt/berücksichtigt.
     * @throws InterruptedException falls das Warten unterbrochen wird.
     */
    public static void main(final String[] args) throws InterruptedException {
        final ClientConfig clientConfig = new ClientConfig();
        clientConfig.setClusterName("demo-cluster");
        final HazelcastInstance client = HazelcastClient.newHazelcastClient(clientConfig);

        final BlockingQueue<Task> queue = client.getQueue("tasks");
        boolean done = queue.offer(new Task());
        LOG.info("Task offers: " + done);
        Task task = queue.poll();
        LOG.info(task);

        // timed blocking Operations
        done = queue.offer(new Task(), 500, TimeUnit.MILLISECONDS);
        LOG.info("Task offers: "+done);
        task = queue.poll(5, TimeUnit.SECONDS);
        LOG.info(task);

        // indefinitely blocking Operations
        queue.put(new Task());
        task = queue.take();
        LOG.info(task);

        client.shutdown();
    }
}
