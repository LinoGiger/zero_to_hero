/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.datagrid.chat.gui;

import ch.hslu.vsk.datagrid.chat.imdg.ChatClient;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Schliesst das Fenster zur Anzeige und Eingabe von Chat Nachrichten und
 * Beendet die Applikation.
 */
public final class ExitListener extends WindowAdapter {

    private final ChatClient client;

    /**
     * Erzeugt einen Listener zur Ueberwachung, wenn der Chat Teilnehmer die
     * Applikation schliesst.
     *
     * @param client Chat Teilnehmer.
     */
    public ExitListener(final ChatClient client) {
        this.client = client;
    }

    @Override
    public void windowClosing(final WindowEvent e) {
        client.disconnect();
        System.exit(0);
    }
}
