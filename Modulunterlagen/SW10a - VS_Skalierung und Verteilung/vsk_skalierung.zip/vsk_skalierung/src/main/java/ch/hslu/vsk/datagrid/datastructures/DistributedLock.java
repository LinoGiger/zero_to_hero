/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.datagrid.datastructures;

import ch.hslu.vsk.datagrid.datastructures.model.Customer;
import com.hazelcast.client.HazelcastClient;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.cp.lock.FencedLock;
import com.hazelcast.map.IMap;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Demo Distributed Locks.
 */
public final class DistributedLock {

    private static final Logger LOG = LogManager.getLogger(DistributedLock.class);

    /**
     * Demo.
     *
     * @param args werden nicht benötigt/berücksichtigt.
     */
    public static void main(String[] args) {
        final ClientConfig clientConfig = new ClientConfig();
        clientConfig.setClusterName("demo-cluster");
        final HazelcastInstance client = HazelcastClient.newHazelcastClient(clientConfig);

        // Lock on Client
        final String mylockobject = "MyLock";
        final FencedLock mylock = client.getCPSubsystem().getLock(mylockobject);
        mylock.lock();
        try {
            // do something
            LOG.info("locked access");
        } finally {
            mylock.unlock();
        }
        // Lock on Map
        final IMap<String, Customer> map = client.getMap("customers");
        map.lock("1");
        try {
            // do something
            LOG.info("locked access");
        } finally {
            map.unlock("1");
        }

        client.shutdown();
    }
}
