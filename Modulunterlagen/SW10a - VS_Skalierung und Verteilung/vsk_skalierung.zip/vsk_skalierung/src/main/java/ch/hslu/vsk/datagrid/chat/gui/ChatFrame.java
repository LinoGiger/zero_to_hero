/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.datagrid.chat.gui;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import java.awt.BorderLayout;
import java.awt.Color;

/**
 * Fenster zur Anzeige und Eingabe von Chat Nachrichten.
 */
public final class ChatFrame extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel jContentPane = null;
    private JPanel jPanel = null;
    private final String titel;

    /**
     * Ausgabe für Chat Nachrichten.
     */
    public JTextArea output;

    /**
     * Eingabe für Chat Nachricht.
     */
    public JTextField input;

    private JPanel getJPanel() {
        if (jPanel == null) {
            jPanel = new JPanel();
            jPanel.setLayout(new BorderLayout());
            output = new JTextArea();
            output.setEditable(false);
            output.setBackground(new Color(255, 255, 204));
            input = new JTextField();
            jPanel.add(output, BorderLayout.CENTER);
            jPanel.add(input, BorderLayout.SOUTH);
        }
        return jPanel;
    }

    /**
     * Erzeugt ein Chat Fenster mit ein- und Ausgabe.
     * 
     * @param titel Chat Fenstertitel.
     */
    public ChatFrame(final String titel) {
        super();
        this.titel = titel;
        initialize();
    }

    private void initialize() {
        this.setSize(300, 300);
        this.setContentPane(getJContentPane());
        this.setTitle("Chat (" + titel + ")");
        input.requestFocus();
    }

    private JPanel getJContentPane() {
        if (jContentPane == null) {
            jContentPane = new JPanel();
            jContentPane.setLayout(new BorderLayout());
            jContentPane.add(getJPanel(), BorderLayout.CENTER);
        }
        return jContentPane;
    }
}
