/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package ch.hslu.vsk.datagrid.datastructures.model;

import java.io.Serializable;

/**
 * Demo User.
 */
public final class Customer implements Serializable {
    
    private static final long serialVersionUID = 3366992011821127366L;
    private final String name;
    private final int age;
    private boolean active;

    /**
     * Erzeugt einen Kunden.
     * 
     * @param name Kundenname.
     * @param age Alter des Kunden.
     * @param active wenn true ist es ein umsatzstarker Kunde, sonst nicht.
     */
    public Customer(String name, int age, boolean active) {
        this.name = name;
        this.age = age;
        this.active = active;
    }

    /**
     * Erzeugt einen umsatzstarken Kunden.
     * 
     * @param name Kundenname.
     */
    public Customer(String name) {
        this(name, 30, true);
    }

    /**
     * Erzeugt einen umsatzstarken Kunden.
     * 
     * @param name Kundenname.
     * @param age Alter des Kunden.
     */
    public Customer(String name, int age) {
        this(name, age, true);
    }

    /**
     * Setzt einen umsatzstarken Kunden auf wenig Umsatz zurück.
     */
    public void setInactive() {
        this.active = false;
    }
    
    @Override
    public String toString() {
        return "Customer{" + "name=" + name + ", active=" + active + ", age=" + age + '}';
    }
}
