/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.zeromq;

import static org.assertj.core.api.Assertions.assertThat;

import java.time.Duration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.Test;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.utility.DockerImageName;
import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

@Testcontainers
 class EchoServerOtherPortIT {

    private static final Logger LOG = LogManager.getLogger(EchoServerOtherPortIT.class);
    private static final int PORT = 4444;
    
    @Container
    GenericContainer<?> server
            = new GenericContainer<>(DockerImageName.parse("rgisler/echoserver:latest"))
                    .withEnv("ECHO_ENDPOINT", "tcp://*:" + PORT)
                    .withStartupTimeout(Duration.ofSeconds(1))
                    .withExposedPorts(PORT);

    @Test
    void testServerStart() {
        final String logs = server.getLogs();
        assertThat(logs).contains("started").contains(Integer.toString(PORT));
    }

    @Test
    void testServerGetEchoAndLog() {
        final String url = String.format("tcp://%s:%s", server.getHost(), server.getFirstMappedPort());
        try ( ZMQ.Socket socket = new ZContext().createSocket(SocketType.REQ)) {
            socket.connect(url);
            socket.send("Hallo Otto!".getBytes(ZMQ.CHARSET));
            assertThat(new String(socket.recv(), ZMQ.CHARSET)).isEqualTo("Hallo Otto!");
        }
        final String logs = server.getLogs();
        assertThat(logs).contains("Hallo Otto!");
    }
}
