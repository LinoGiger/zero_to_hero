/*
 * Copyright 2022 Hochschule Luzern Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.zeromq;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.assertj.core.api.Assertions.assertThat;

import java.io.File;
import java.time.Duration;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.jupiter.api.Test;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;
import org.testcontainers.containers.GenericContainer;
import org.testcontainers.images.builder.ImageFromDockerfile;

@Testcontainers
class EchoClientAdHocDistrolessIT {

    private static final Logger LOG = LogManager.getLogger(EchoClientAdHocDistrolessIT.class);
    private static final int PORT = 5555;

    @Container
    GenericContainer<?> server
            = new GenericContainer<>(new ImageFromDockerfile("ad-hoc/echoserver-distroless", true)
                    .withFileFromFile("./target/vsk-echoserver.jar", new File("./target/vsk-echoserver.jar"))
                    .withDockerfileFromBuilder(builder -> builder
                        .from("gcr.io/distroless/java17-debian11:latest")
                        .expose(PORT)
                        .copy("./target/vsk-echoserver.jar", "/vsk-echoserver.jar")
                        .cmd(new String[]{"vsk-echoserver.jar"})
                        .build()))
                    .withStartupTimeout(Duration.ofSeconds(1))
                    .withExposedPorts(PORT);

    @Test
    void testEchoClient() {
        final String url = String.format("tcp://%s:%s", server.getHost(), server.getFirstMappedPort());
        final EchoClient ec = new EchoClient(url);
        final String echo = ec.getEcho("TEST-MESSAGE");
        final String logs = server.getLogs();
        assertAll(
            () -> assertThat(logs).contains("EchoServer on 'Debian' started"),
            () -> assertThat(logs).contains(Integer.toString(PORT)),
            () -> assertThat(echo).isEqualTo("TEST-MESSAGE")
        );
    }
}
