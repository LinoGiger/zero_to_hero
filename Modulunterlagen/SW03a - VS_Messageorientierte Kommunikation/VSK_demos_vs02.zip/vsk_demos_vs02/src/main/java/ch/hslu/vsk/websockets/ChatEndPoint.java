/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.websockets;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.jetty.websocket.api.Session;
import org.eclipse.jetty.websocket.api.WebSocketListener;

/**
 * WebSocket communication end point for a basic chat server.
 * First received message is the username, all following messages
 * are chat messages sent to the other chat participants.
 *
 * This server does not use any kind of safety or security mechanisms.
 */
public class ChatEndPoint implements WebSocketListener {
    private static final Logger LOG = LogManager.getLogger(ChatEndPoint.class);
    private static final ChatSessions CHAT_SESSIONS = new ChatSessions();

    private Session session;
    private String username;

    @Override
    public void onWebSocketConnect(Session session) {
        this.session = session;
        CHAT_SESSIONS.add(session);
    }

    @Override
    public void onWebSocketClose(int statusCode, String reason){
        CHAT_SESSIONS.remove(session);
    }

    @Override
    public void onWebSocketError(Throwable cause){
        CHAT_SESSIONS.remove(session);
        LOG.error("web socket error occurred" , cause);
    }

    @Override
    public void onWebSocketText(String message) {
        if (username == null) {
            username = message;
        } else {
            CHAT_SESSIONS.broadcast(username + ": " + message);
        }
    }

    @Override
    public void onWebSocketBinary(byte[] payload, int offset, int length) {
        throw new RuntimeException("unimplemented");
    }
}
