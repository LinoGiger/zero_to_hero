/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.zeromq;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Basic EchoClient using ZeroMQ.
 */
public class EchoClient {
    private static final Logger LOG = LogManager.getLogger(EchoClient.class);
    public static final String ADDRESS = "tcp://localhost:5555";

    public static void main(String[] args) {
        try (ZContext context = new ZContext()) {
            LOG.info("Echo client connecting to " + ADDRESS);

            ZMQ.Socket socket = context.createSocket(SocketType.REQ);
            socket.connect(ADDRESS);

            BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));
            while(true) {
                String input = userIn.readLine();
                socket.send(input.getBytes(ZMQ.CHARSET));
                byte[] reply = socket.recv();
                LOG.info("Received message: " + new String(reply, ZMQ.CHARSET));
            }
        } catch (IOException ex) {
            LOG.error(ex.getMessage());
        }
    }
}
