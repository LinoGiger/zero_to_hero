/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.zeromq;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

/**
 * Pushes tasks from to consumers for processing.
 */
public class Producer {
    private static final Logger LOG = LogManager.getLogger(Producer.class);
    public static final String ADDRESS = "tcp://localhost:5555";

    public static void main(String[] args) {
        try (ZContext context = new ZContext()) {
            LOG.info("Providing tasks on " + ADDRESS);

            ZMQ.Socket socket = context.createSocket(SocketType.PUSH);
            socket.connect(ADDRESS);

            int i = 0;
            while(true) {
                String workPackage = "Work Package #" + ++i;
                socket.send(workPackage.getBytes(ZMQ.CHARSET), 0);
                LOG.info("Send task '" + workPackage + "'");
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            LOG.info("interrupted"); // cannot occur
        }
    }
}
