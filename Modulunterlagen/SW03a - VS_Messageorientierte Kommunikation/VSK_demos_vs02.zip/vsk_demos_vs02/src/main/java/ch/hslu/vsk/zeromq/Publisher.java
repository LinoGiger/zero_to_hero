/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.zeromq;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

/**
 * Publisher simulating a device that measures temperature.
 */
public class Publisher {
    private static final Logger LOG = LogManager.getLogger(Publisher.class);
    public static final String ADDRESS = "tcp://localhost:5555";

    public static void main(String[] args)  {
        try (ZContext context = new ZContext()) {
            ZMQ.Socket socket = context.createSocket(SocketType.PUB);
            socket.bind(ADDRESS);

            while (true) {
                long station = (long) Math.floor(Math.random() * 3.0);
                long temp = 15 + (long) Math.floor(Math.random() * 10.0);
                String message = "Temp/" + station + "/" + temp;

                socket.send(message.getBytes(ZMQ.CHARSET));
                LOG.info("Published '" + message + "'");

                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            LOG.info("interrupted"); // cannot occur
        }
    }
}
