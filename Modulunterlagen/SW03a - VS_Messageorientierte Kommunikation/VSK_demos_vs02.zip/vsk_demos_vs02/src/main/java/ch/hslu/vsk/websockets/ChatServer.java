/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.websockets;

import jakarta.servlet.Servlet;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.eclipse.jetty.websocket.server.JettyWebSocketServlet;
import org.eclipse.jetty.websocket.server.JettyWebSocketServletFactory;
import org.eclipse.jetty.websocket.server.config.JettyWebSocketServletContainerInitializer;

import java.time.Duration;

public class ChatServer  {
    private static final Logger LOG = LogManager.getLogger(ChatServer.class);
    private static final int PORT = 8080;

    public static void main(String[] args) throws Exception {
        // create new web server with a servlet context handler
        Server server = new Server(PORT);
        ServletContextHandler servletContextHandler = new ServletContextHandler();
        server.setHandler(servletContextHandler);

        // create a websocket servlet configured with the ChatEndPoint at url path /chat
        Servlet websocketServlet = new JettyWebSocketServlet() {
            @Override protected void configure(JettyWebSocketServletFactory factory) {
                factory.setIdleTimeout(Duration.ofMinutes(30));
                factory.addMapping("/", (req, res) -> new ChatEndPoint());
            }
        };
        servletContextHandler.addServlet(new ServletHolder(websocketServlet), "/chat");
        JettyWebSocketServletContainerInitializer.configure(servletContextHandler, null);

        // start web server
        server.start();
        LOG.info("Chat server listening on port " + PORT);
    }
}
