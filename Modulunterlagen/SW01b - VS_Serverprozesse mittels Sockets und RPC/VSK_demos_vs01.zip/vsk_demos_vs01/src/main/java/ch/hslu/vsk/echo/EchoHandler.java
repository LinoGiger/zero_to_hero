/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.echo;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

/**
 * Implements a thread-based handling of echo client connections.
 * Inside a loop the EchoHandler waits for an incoming message
 * (EchoMessage.getMessage). After it has received an incoming
 * message the handler replies with an outgoing message.
 */
public class EchoHandler implements Runnable {
    private static final Logger LOG = LogManager.getLogger(EchoHandler.class);
    private final Socket client;

    public EchoHandler(final Socket client) {
        this.client = client;
    }

    @Override
    public void run() {
        LOG.info("Connection to " + client);
        try (DataInputStream in = new DataInputStream(client.getInputStream());
            DataOutputStream out = new DataOutputStream(client.getOutputStream())) {

            while (true) {
                String message = EchoMessage.getMessage(in);
                EchoMessage.sendMessage(out, message);
                out.flush();
            }
        } catch (IOException ex) {
            LOG.debug(ex.getMessage());
        }
    }
}
