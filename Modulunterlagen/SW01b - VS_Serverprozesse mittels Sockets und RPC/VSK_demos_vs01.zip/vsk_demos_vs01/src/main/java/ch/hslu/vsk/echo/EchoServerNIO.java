/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.echo;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;
import java.util.Set;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Server program implementing a simple echo request response protocol.
 * The server repeats each message sent by the client.
 * The message format is a 32-bit integer containing the length n of a
 * string followed by n bytes of UTF-8 encoded characters.
 * The server uses a single thread with non-blocking IO. The design
 * allows the server to handle a large number of simultaneous
 * connections (depending on the load and machine capacity).
 */
public class EchoServerNIO {
    private static final Logger LOG = LogManager.getLogger(EchoServerNIO.class);
    private static final int PORT = 7777;

    private static class State {
        ByteBuffer messageLength = ByteBuffer.allocate(4);
        ByteBuffer messageContent = null;
        ByteBuffer outgoingMessage = null;
    }

    private static Selector selector = null;

    public static void main(String[] args) {
        try {
            selector = Selector.open();
            ServerSocketChannel socket = ServerSocketChannel.open();
            ServerSocket serverSocket = socket.socket();
            serverSocket.bind(new InetSocketAddress("localhost", PORT));
            socket.configureBlocking(false);
            socket.register(selector, SelectionKey.OP_ACCEPT);

            // "event" loop: wait for accept/read/write events and handles them
            while (true) {
                selector.select();
                Set<SelectionKey> selectedKeys = selector.selectedKeys();
                Iterator<SelectionKey> i = selectedKeys.iterator();
                while (i.hasNext()) {
                    SelectionKey key = i.next();
                    if (key.isAcceptable())  { handleAccept(socket); }
                    else if (key.isReadable()) { handleRead(key); }
                    else if (key.isWritable()) { handleWrite(key); }
                    i.remove();
                }
            }
        } catch (IOException e) {
            LOG.error(e);
        }
    }

    private static void handleAccept(ServerSocketChannel mySocket) throws IOException {
        SocketChannel client = mySocket.accept();
        client.configureBlocking(false);
        client.register(selector, SelectionKey.OP_READ, new State());
        LOG.info("Opened connection to Client: " + client.getRemoteAddress());
    }

    private static void handleRead(SelectionKey key) throws IOException {
        SocketChannel client = (SocketChannel) key.channel();
        State state = (State) key.attachment();

        try {
            if (state.messageContent != null) {
                int read = client.read(state.messageContent);
                if (read == -1) {
                    closeConnection(key);
                    return;
                }
                if (!state.messageContent.hasRemaining()) {
                    createOutgoingMessage(state);
                    LOG.info("Received echo from (client: " + client.getRemoteAddress() + ")");
                    client.register(selector, SelectionKey.OP_WRITE, state);
                }
            } else {
                int read = client.read(state.messageLength);
                if (read == -1) {
                    closeConnection(key);
                    return;
                }
                if (!state.messageLength.hasRemaining()) {
                    state.messageLength.rewind();
                    state.messageContent = ByteBuffer.allocate(state.messageLength.getInt());
                    state.messageLength.clear();
                }
            }
        } catch (IOException e) {
            closeConnection(key);
        }
    }

    private static void createOutgoingMessage(State state) {
        state.messageContent.rewind();
        state.outgoingMessage = ByteBuffer.allocate(state.messageContent.capacity() + 4); // +4 for Length
        state.outgoingMessage.putInt(state.messageContent.capacity());
        state.outgoingMessage.put(state.messageContent);
        state.outgoingMessage.rewind();
        state.messageContent = null;
    }

    private static void handleWrite(SelectionKey key) throws IOException {
        SocketChannel client = (SocketChannel) key.channel();
        State state = (State) key.attachment();

        try {
            client.write(state.outgoingMessage);
            if (!state.outgoingMessage.hasRemaining()) {
                // outgoing message sent. switch to incoming message
                client.register(selector, SelectionKey.OP_READ, state);
                LOG.info("Send echo to client: " + client.getRemoteAddress() + "");
            }
        } catch (IOException e) {
            closeConnection(key);
        }
    }

    private static void closeConnection(SelectionKey key) throws IOException {
        SocketChannel client = (SocketChannel) key.channel();
        LOG.info("Closed connection to " + client.getRemoteAddress());
        key.cancel();
        client.close();
    }
}
