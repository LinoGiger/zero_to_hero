/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.daytime;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.DataInputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.charset.StandardCharsets;

/**
 * Connects to a server on localhost that implements the daytime protocol.
 * The program queries the server and outputs its response to the console.
 */
public class DaytimeClient {
    private static final Logger LOG = LogManager.getLogger(DaytimeClient.class);
    private static final int PORT = 1300;

    public static void main(String[] args) throws IOException {
        // note: try-with-resources automatically closes socket
        try (Socket socket = new Socket("localhost", PORT)) {
            DataInputStream is = new DataInputStream(socket.getInputStream());
            byte[] bytes = is.readAllBytes();
            String time = new String(bytes, StandardCharsets.UTF_8);
            LOG.info(time);
        } catch (IOException e) {
            LOG.error(e);
        }
    }
}
