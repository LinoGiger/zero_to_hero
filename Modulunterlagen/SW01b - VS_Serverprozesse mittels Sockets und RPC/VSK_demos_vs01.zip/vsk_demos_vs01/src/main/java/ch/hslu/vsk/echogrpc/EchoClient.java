/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.echogrpc;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * Echo client using the gRPC echo protocol as defined in echogrpc.proto.
 * The client sends a EchoRequest and expects the server to reply with
 * an EchoResponse.
 */
public class EchoClient {
    private static final Logger LOG = LogManager.getLogger(ch.hslu.vsk.echogrpc.EchoClient.class);
    private static final int PORT = 5001;

    public static void main(String[] args) {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", PORT)
                .usePlaintext()
                .build();

        EchoServiceGrpc.EchoServiceBlockingStub stub = EchoServiceGrpc.newBlockingStub(channel);
        BufferedReader userIn = new BufferedReader(new InputStreamReader(System.in));
        try {
            while (true) {
                String input = userIn.readLine();
                Echo.EchoRequest echoRequest = Echo.EchoRequest.newBuilder().setMessage(input).build();
                Echo.EchoResponse echo = stub.echo(echoRequest);
                LOG.info(echo.getMessage());
            }
        } catch (IOException e) {
            LOG.error(e);
        }
        channel.shutdown();
    }
}
