/*
 * Copyright 2022 Hochschule Luzern - Informatik.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package ch.hslu.vsk.daytime;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Date;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Server program implementing the Daytime protocol (<a href="https://www.rfc-editor.org/rfc/rfc867.html">RFC 867</a>).
 * The server uses a single thread for accepting and processing connections.
 * After a connection is established, the program immediately sends the daytime
 * string, closes the connection, and waits for a new connection.
 */
public class DaytimeServer {
    private static final Logger LOG = LogManager.getLogger(DaytimeServer.class);
    private static final int PORT = 1300;

    public static void main(final String[] args) {
        LOG.info("Listening for connections on port " + PORT);
        try (ServerSocket listen = new ServerSocket(PORT, 50, InetAddress.getByName("localhost"))) {
            while (true) {
                try (Socket client = listen.accept()) {
                    LOG.info("Connection to " + client.getInetAddress());
                    DataOutputStream os = new DataOutputStream(client.getOutputStream());
                    Date date = new Date();
                    os.write((date.toString()).getBytes());
                    LOG.info("Sent " + date + " to " + client.getInetAddress());
                }
            }
        } catch (IOException ex) {
            LOG.debug(ex.getMessage());
        }
    }
}
